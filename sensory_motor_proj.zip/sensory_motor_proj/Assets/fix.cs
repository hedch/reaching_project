﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fix : MonoBehaviour {


    //This class makes the retinas rotate to fix on a pre-defined fixation point. 

    GameObject left_eye;
    GameObject right_eye;
    Camera left_retina;
    Camera right_retina;

    Vector2 front = new Vector2(1, 0);

    public float agl_lh;
    public float agl_lv;
    public float agl_rh;
    public float agl_rv;

    // Use this for initialization
    void Start () {
        left_eye = GameObject.Find("lefteye");
        right_eye = GameObject.Find("righteye");
        left_retina = left_eye.transform.Find("Camera").gameObject.GetComponent<Camera>();
        right_retina = right_eye.transform.Find("Camera").gameObject.GetComponent<Camera>();
    }

    public void fix_to_obj(GameObject fixation) {


        Vector3 left_view = fixation.transform.position - left_eye.transform.position;
        Vector3 right_view = fixation.transform.position - right_eye.transform.position;
        Vector2 left_view_h = new Vector2(left_view.x, left_view.z);
        Vector2 left_view_v = new Vector2(left_view.x, left_view.y);
        Vector2 right_view_h = new Vector2(right_view.x, right_view.z);
        Vector2 right_view_v = new Vector2(right_view.x, right_view.y);

        agl_lh = Mathf.Acos(Vector2.Dot(left_view_h, front) / Mathf.Sqrt(Vector2.SqrMagnitude(left_view_h))) * 180 / Mathf.PI;
        agl_lv = Mathf.Acos(Vector2.Dot(left_view_v, front) / Mathf.Sqrt(Vector2.SqrMagnitude(left_view_v))) * 180 / Mathf.PI;
        agl_rh = Mathf.Acos(Vector2.Dot(right_view_h, front) / Mathf.Sqrt(Vector2.SqrMagnitude(right_view_h))) * 180 / Mathf.PI;
        agl_rv = Mathf.Acos(Vector2.Dot(right_view_v, front) / Mathf.Sqrt(Vector2.SqrMagnitude(right_view_v))) * 180 / Mathf.PI;

        if (fixation.transform.position.y < left_eye.transform.position.y)
        {

            agl_lv = -agl_lv;
            agl_rv = -agl_rv;
        }

        if (fixation.transform.position.z > left_eye.transform.position.z)
        {

            agl_lh = -agl_lh;
        }

        if (fixation.transform.position.z > right_eye.transform.position.z)
        {

            agl_rh = -agl_rh;
        }

        left_eye.transform.Rotate(new Vector3(0, agl_lh, agl_lv), Space.World);
        right_eye.transform.Rotate(new Vector3(0, agl_rh, agl_rv), Space.World);
    }

    public byte[] capture_camera(string lr) {
        Camera camera;
        if (lr == "l")
        {

            camera = left_retina;
        }
        else if (lr == "r")
        {

            camera = right_retina;
        }
        else {

            camera = left_retina;
        }

        Rect rect = new Rect(0, 0, 300, 300);

        RenderTexture rt = new RenderTexture((int)rect.width, (int)rect.height, 3);
        camera.targetTexture = rt;
        camera.Render();

        RenderTexture.active = rt;
        Texture2D screenShot = new Texture2D((int)rect.width, (int)rect.height, TextureFormat.RGB24, false);
        screenShot.ReadPixels(rect, 0, 0);
        screenShot.Apply();
        camera.targetTexture = null;
        RenderTexture.active = null;
        GameObject.Destroy(rt);
        byte[] bytes = screenShot.EncodeToPNG();
        return bytes;

    }
	
}
