﻿using System.Collections.Generic;
using UnityEngine;
using SocketIO;


// This class set up the communication between Unity3D and python.
public class tcp_ip : MonoBehaviour
{
    
    public SocketIOComponent sio;
    public string received_info;
    public bool received;
   

    void Start()
    {
        received = false;
        received_info = "";

        if (sio == null)
            Debug.LogError("Drop a SocketIOComponent to Me!");
      
        sio.On("connect", OnConnect);
        sio.On("server_sent", OnReceive);
    }


    void OnConnect(SocketIOEvent obj)
    {
        Debug.Log("Connection Open");
        OnReceive(obj);
    }


    void OnReceive(SocketIOEvent obj)
    {
        
        JSONObject jsonObject = obj.data;
        received_info = jsonObject.GetField("nbr").str;
        if (received_info.Length > 2)
        {

            received = true;
        }
       
       
    
      
    }


    public void SendToServer(Dictionary<string, string> data)
    {
       
        sio.Emit("client_sent", new JSONObject(data));
    }
}