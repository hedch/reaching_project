﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class joint : MonoBehaviour {

    private string objectName;
    private int joint_number;
    GameObject zero;
    //  arm_move mainScript;
    arm_move mainScript;
    float[] temp_angle = { 0, 0, 0 };
    int axis_number;

  


    // Use this for initialization
    void Start () {

        zero = GameObject.Find("Cube0");
        objectName = gameObject.name;
        joint_number = int.Parse(objectName.Substring(5, 1));
        
        mainScript = zero.GetComponent<arm_move>();
        axis_number = mainScript.axis_number[joint_number];


    }
	
	


    public int Axis_number
    {
        get
        {
            return axis_number;
        }
        set
        {
            axis_number = Axis_number;
        }

    }


    public float read_tempangle()
    {
        return temp_angle[Axis_number];
    }

    public void changetemp_angle(float angle)
    {
        temp_angle[Axis_number] = -angle;
        transform.localRotation = Quaternion.Euler(temp_angle[0], temp_angle[1], temp_angle[2]);

    }
    public void angleMove(float ang)
    {
        if (ang > 180)
        {
            while (ang > 180)
            {
                ang -= 360;
            }
        }
        else if (ang < -180)
        {
            while (ang < -180)
            {

                ang += 360;
            }

        }
        temp_angle[Axis_number] = ang;

        transform.localRotation = Quaternion.Euler(temp_angle[0], temp_angle[1], temp_angle[2]);
    }

}
