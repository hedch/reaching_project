﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MathNet.Numerics.Data.Text;
using MathNet.Numerics.LinearAlgebra;
using System.Text;
using System.IO;
using MathNet.Numerics.LinearAlgebra.Double;
using System;

public class arm_move : MonoBehaviour {

    GameObject[] capsuleArray = new GameObject[2];
    GameObject[] sphereArray = new GameObject[3];
    GameObject[] cubeArray = new GameObject[4];
    GameObject[] jointArray = new GameObject[7];
    GameObject nb;
    GameObject head;
    GameObject target;
    GameObject targetv;
    GameObject comm;
    GameObject fix_pic;
    GameObject fixation;
 


    public int[] axis_number = new int[] { 1, 2, 0, 1, 2, 2, 0 };

    float _timer = 0f;
    int step = 0;
    public int num_trial = 50;
    const int max_step = 5;

    float[] _err = new float[max_step];
    public float[] current_config;
    public float[] test_config = new float[] { 0, 0, 0, 0, 0, 0, 0 };
    bool permit = true;
    bool sample = false;

    public int index = 0;
    bool state;

    Vector3 vst;
    Vector3 wpos;
    float[,] sample_arm = new float[5400,4];
    Matrix<float> data;
    //DenseMatrix data = new DenseMatrix(54, 3);

    tcp_ip _tcpip;
    fix _fix;

    // Use this for initialization
    void Start () {
        InitObject();
        FixJoints();
        SetPSRelationship();
        target = GameObject.Find("target");
        targetv = GameObject.Find("targetv");
        comm = GameObject.Find("comm");
        fix_pic = GameObject.Find("fix_pic");
        set_angle(new float[] { 0, 0, 0, 0, 0, 0, 0 });
        fixation = GameObject.Find("fix");

        //  sample_arm = sample_arm_pic();
        // sample_arm = test_arm_pos();

        _tcpip = comm.GetComponent<tcp_ip>();
        _fix = fix_pic.GetComponent<fix>();

        data = DelimitedReader.Read<float>(Application.dataPath + "//" + "test_wrist_pos_m2.csv", false, ",",false);
        _fix.fix_to_obj(fixation);
        _tcpip.received = false;
    }


    void OnGUI()//By clicking the button Send, images are sent to the python end via tcp-ip and will be processed there and send back a motion code, which then be get by clicking "Ask". 
    {

        if (GUI.Button(new Rect(10, 50, 50, 30), "ASK"))//ask for motion command when img processed (ready)
        {

            Dictionary<string, string> _data = new Dictionary<string, string>();
            _data["f"] = "false";
            _data["move"] = "true";
            comm.transform.GetComponent<tcp_ip>().SendToServer(_data);
        }

            if (GUI.Button(new Rect(10, 20, 50, 30), "SEND"))//send img 
        {
            
            Dictionary<string, string> _data = new Dictionary<string, string>();
            if (step < max_step)
            {
                byte[] leftimage = fix_pic.transform.GetComponent<fix>().capture_camera("l");
                byte[] rightimage = fix_pic.transform.GetComponent<fix>().capture_camera("r");
                Collider coll = target.transform.GetComponent<BoxCollider>();
                Vector3 closepoint = coll.ClosestPointOnBounds(sphereArray[2].transform.position);
                _err[step] = Vector3.Distance(closepoint, sphereArray[2].transform.position) - sphereArray[2].transform.localScale[0] / 2;
                current_config = get_angle();

                _data["f"] = "false";
                _data["move"] = "false";
                _data["step"] = step.ToString();
                _data["imagel"] = Convert.ToBase64String(leftimage);
                _data["imager"] = Convert.ToBase64String(rightimage);
                _data["th1"] = current_config[0].ToString();
                _data["th2"] = current_config[1].ToString();
                _data["th3"] = current_config[2].ToString();
                _data["th4"] = current_config[4].ToString();

                Vector3 a = targetv.transform.position - target.transform.position;
                Vector3 h = cubeArray[1].transform.position - sphereArray[2].transform.position;
                Vector3 hn = sphereArray[2].transform.position - sphereArray[1].transform.position;
                float hand_rot = Mathf.Acos(Vector3.Dot(h, a) / (Vector3.Magnitude(h) * Vector3.Magnitude(a))) * 180 / Mathf.PI;
                float hand_n = Mathf.Acos(Vector3.Dot(hn, a) / (Vector3.Magnitude(hn) * Vector3.Magnitude(a))) * 180 / Mathf.PI;
                _data["err"] = _err[step].ToString();
                _data["arr"] = (hand_rot-hand_n).ToString();
                _data["ntr"] = num_trial.ToString();

                comm.transform.GetComponent<tcp_ip>().SendToServer(_data);
            }else if (step == max_step)
            {

                _data["f"] = "true";
                _data["0"] = (-current_config[0]).ToString();
                _data["1"] = current_config[1].ToString();
                _data["2"] = current_config[2].ToString();
                _data["3"] = current_config[3].ToString();
                _data["4"] = current_config[4].ToString();
                _data["5"] = current_config[5].ToString();
                _data["6"] = current_config[6].ToString();

                _data["7"] = sphereArray[2].transform.position.x.ToString() + "/" + sphereArray[2].transform.position.z.ToString() + "/" + sphereArray[2].transform.position.y.ToString();
                _data["8"] = cubeArray[3].transform.position.x.ToString() + "/" + cubeArray[3].transform.position.z.ToString() + "/" + cubeArray[3].transform.position.y.ToString();
                _data["9"] = cubeArray[2].transform.position.x.ToString() + "/" + cubeArray[2].transform.position.z.ToString() + "/" + cubeArray[2].transform.position.y.ToString();
                _data["10"] = cubeArray[1].transform.position.x.ToString() + "/" + cubeArray[1].transform.position.z.ToString() + "/" + cubeArray[1].transform.position.y.ToString();
                comm.transform.GetComponent<tcp_ip>().SendToServer(_data);

                set_angle(new float[] { 0, 0, 0, 0, 0, 0, 0 });
                
                num_trial--;
                step = 0;


            }
           
        }
    }

   

        // Update is called once per frame
        void Update () {
  
        _timer += Time.deltaTime;

      

        if (_timer > 1 && index < 10 && permit && sample)// Sample arm configurations during training
        {

            _timer = 0;
            // System.Random ran = new System.Random();
            // int k = ran.Next(0, 1000);

            //  set_angle(new float[] { sample_arm[index, 0], sample_arm[index,1], sample_arm[index,2], 0, sample_arm[index,3], 0, 0 });

            //  data[index, 0] = sphereArray[2].transform.position.x;
            //  data[index, 1] = sphereArray[2].transform.position.y;
            //  data[index, 2] = sphereArray[2].transform.position.z;

            target.transform.position = new Vector3(data[index, 0], data[index, 1], data[index, 2]);
            byte[] leftimage = fix_pic.transform.GetComponent<fix>().capture_camera("l");
            byte[] rightimage = fix_pic.transform.GetComponent<fix>().capture_camera("r");
            string filenamel = Application.dataPath + "//"+"test_pic"+"//" + index.ToString() + "l.png";
            string filenamer = Application.dataPath + "//" + "test_pic" + "//" + index.ToString() + "r.png";
            File.WriteAllBytes(filenamel, leftimage);
            File.WriteAllBytes(filenamer, rightimage);

            index++;
            
          // if (index == 54)
          // {
            //    string file_name = "test_wrist_pos_m2.csv";
              //  DelimitedWriter.Write(Application.dataPath + "//" + file_name, data, ",");

        //    }
        }

 

        if (num_trial == 0) {
            permit = false;
        }

        

        if (step < max_step && permit && !sample)//Keeping listening via tcp-ip and detect the motion code.
        {
           

            //Vector3 ds = target.transform.position - sphereArray[2].transform.position;


            state = _tcpip.received;
          

            if (state) {
                _tcpip.received = false;
                string mv = _tcpip.received_info;
                string[] _mv = mv.Split('#');
                float[] move = new float[] { };


                if (step == 0)
                {

                    move = new float[] { float.Parse(_mv[0]), float.Parse(_mv[1]), float.Parse(_mv[2]), 0, float.Parse(_mv[3]), 0, 0 };


                }
                else {
                    Vector3 a = targetv.transform.position - target.transform.position;
                    Vector3 h = cubeArray[1].transform.position - sphereArray[2].transform.position;
                    float hand_rot = Mathf.Acos(Vector3.Dot(h, a) / (Vector3.Magnitude(h) * Vector3.Magnitude(a))) * 180 / Mathf.PI;

                    Vector3 b = sphereArray[1].transform.position - sphereArray[2].transform.position;
                    Vector3 c = sphereArray[0].transform.position - sphereArray[1].transform.position;
                    Vector3 t = Vector3.Cross(a, b);
                    Vector3 n = Vector3.Cross(b, c);
                    Vector3 p = Vector3.Cross(n, b);
                    float elbow_rot = Mathf.Acos(Vector3.Dot(p, t) / (Vector3.Magnitude(p) * Vector3.Magnitude(t))) * 180 / Mathf.PI;
                    float wrist_rot = 180 - Mathf.Acos(Vector3.Dot(b, a) / (Vector3.Magnitude(b) * Vector3.Magnitude(a))) * 180 / Mathf.PI;

                    current_config = get_angle();
                    float ita = _err[step] / 2;
                    float gamma = _err[step] / _err[0];

                    move = new float[] { current_config[0] + ita * float.Parse(_mv[0]) ,current_config[1] + ita * float.Parse(_mv[1])
                    , current_config[2] + ita * float.Parse(_mv[2]),elbow_rot, current_config[4] + ita * float.Parse(_mv[3]) ,0,wrist_rot };

                   

                    if (gamma < 0.2)
                    {

                       move[5] = hand_rot;
                    }
                }
              
                
                
    
                set_angle(opt_config(move));
                step++;

                if (step == max_step)
                {


                    set_angle(new float[] { 0, 0, 0, 0, 0, 0, 0 });

                    num_trial--;

                    target.transform.position = new Vector3(data[num_trial, 0], data[num_trial, 1], data[num_trial, 2]);
                    step = 0;
               

                }
     
                
            }
          
            
        }

    }

    float[,] test_arm_pos()//test target locations are acquired by sampling the arm configurations that have not been used during the training.
    {

        int s = 0;
        float[,] sa = new float[54, 4];
        for (int i = 0; i < 2; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                for (int k = 0; k <3; k++)
                {
                    for (int l = 0; l < 3; l++)
                    {
                        sa[s, 0] = -i * 15 - 45;
                        sa[s, 1] = j * 30 + 60;
                        sa[s, 2] = k * 6 + 6;
                        sa[s, 3] = l * 30 + 30;
                        s++;
                    }
                }
            }
        }
        return sa;
    }

    float[,] sample_arm_pic() {//arm configurations during training

        int s = 0;
        float [,] sa = new float[5400, 4];
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 10; j++) {
                for (int k = 0; k < 4; k++) {
                    for (int l = 0; l < 15; l++){
                        sa[s, 0] = -i * 6 - 25;
                        sa[s, 1] = j * 6 + 65;
                        sa[s, 2] = k * 6 + 2;
                        sa[s, 3] = l * 6 + 4;
                        s++;
                    }
                }
            }
        }
        return sa;
    }


    float[] opt_config(float[] config) {//define the rotation range for each joint
        float[] _config = config;
        if (_config[0] > 0)
        {
            _config[0] = -5f;
        }
        else if (_config[0] < -90) {
            _config[0] = -85f;
        }

        if (_config[1] < 0)
        {
            _config[1] = 5f;
        }
        else if (_config[1] > 90)
        {
            _config[1] = 85f;
        }

        if (_config[2] < 0)
        {
            _config[2] = 5f;
        }
        else if (_config[2] > 120)
        {
            _config[2] = 115f;
        }
        
        if (_config[3] > 105)
        {
            _config[3] = 105f;
        }

        if (_config[4] < 0)
        {
            _config[4] = 5f;
        }
        else if (_config[4] > 140)
        {
            _config[4] = 135f;
        }

        if (_config[5] > 15)
        {
            _config[5] = 15f;
        }

        if (_config[6] > 50)
        {
            _config[6] = 50f;
        }
        return _config;

    }

    float exo_w(float d) {
        if (d > 0.333f)
        {
            return 0.5f * (1 - d);
        }
        else {
            return 1 - 2 * d;
        }

    }

    //initialize arm kinematics including the relations among joints
    void InitObject()
    {

        string objName;
        for (int i = 0; i < jointArray.Length; i++)
        {
            objName = string.Format("Joint{0}", i);
            jointArray[i] = GameObject.Find(objName);
        }

        for (int i = 0; i < capsuleArray.Length; i++)
        {
            objName = string.Format("Capsule{0}", i);
            capsuleArray[i] = GameObject.Find(objName);
        }
        for (int i = 0; i < sphereArray.Length; i++)
        {
            objName = string.Format("Sphere{0}", i);
            sphereArray[i] = GameObject.Find(objName);
        }
        for (int i = 0; i < cubeArray.Length; i++)
        {
            objName = string.Format("Cube{0}", i);
            cubeArray[i] = GameObject.Find(objName);
        }

        nb = GameObject.Find("nb");
        head = GameObject.Find("Main Camera");
    }

    void FixJoints()
    {
        for (int i = 0; i < 3; i++)
        {
            jointArray[i].transform.position = sphereArray[0].transform.position;
            jointArray[i].transform.rotation = sphereArray[0].transform.rotation;
        }
        for (int i = 3; i < 5; i++)
        {
            jointArray[i].transform.position = sphereArray[1].transform.position;
            jointArray[i].transform.rotation = sphereArray[1].transform.rotation;
        }
        for (int i = 5; i < 7; i++)
        {
            jointArray[i].transform.position = sphereArray[2].transform.position;
            jointArray[i].transform.rotation = sphereArray[2].transform.rotation;
        }

    }

    void SetPSRelationship()
    {
        
        cubeArray[1].transform.parent = jointArray[6].transform;
        jointArray[6].transform.parent = jointArray[5].transform;
        jointArray[5].transform.parent = sphereArray[2].transform;
        sphereArray[2].transform.parent = capsuleArray[1].transform;
        capsuleArray[1].transform.parent = jointArray[3].transform;
        jointArray[3].transform.parent = jointArray[4].transform;
        jointArray[4].transform.parent = sphereArray[1].transform;
        sphereArray[1].transform.parent = capsuleArray[0].transform;
        capsuleArray[0].transform.parent = jointArray[0].transform;
        jointArray[0].transform.parent = sphereArray[0].transform;
        sphereArray[0].transform.parent = jointArray[2].transform;
        jointArray[2].transform.parent = jointArray[1].transform;
        jointArray[1].transform.parent = cubeArray[0].transform;

    }

    void set_angle(float[] angle)
    {

        jointArray[0].transform.GetComponent<joint>().angleMove(angle[0]);

        jointArray[1].transform.GetComponent<joint>().angleMove(angle[1]);
        jointArray[2].transform.GetComponent<joint>().angleMove(angle[2]);

        jointArray[3].transform.GetComponent<joint>().angleMove(angle[3]);
        jointArray[4].transform.GetComponent<joint>().angleMove(angle[4]);
        jointArray[5].transform.GetComponent<joint>().angleMove(angle[5]);
        jointArray[6].transform.GetComponent<joint>().angleMove(angle[6]);



    }
    float[] get_angle()
    {

        float[] jointAngleRealTime = new float[7];
        for (int i = 0; i < 7; i++)
        {
            jointAngleRealTime[i] = jointArray[i].GetComponent<joint>().read_tempangle();
        }
        return jointAngleRealTime;
    }
}
